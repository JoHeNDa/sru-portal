export type UiSound = 'success' | 'delete' | 'attention';

const SOUND_SETTING = 'sru-ui-sounds';
const ATTENTION_SETTING = 'sru-last-attention-sound';
let audioContext: AudioContext | null = null;

function getAudioContext() {
  if (!window.AudioContext) return null;
  if (!audioContext || audioContext.state === 'closed') audioContext = new window.AudioContext();
  return audioContext;
}

export function primeUiSounds() {
  if (typeof window === 'undefined' || window.localStorage.getItem(SOUND_SETTING) === 'off') return;
  const context = getAudioContext();
  if (context?.state === 'suspended') {
    void context.resume().catch(error => console.debug('UI audio could not be enabled:', error));
  }
}

function playTone(context: AudioContext, sound: UiSound) {
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  const now = context.currentTime;
  const frequency = sound === 'delete' ? 330 : sound === 'attention' ? 660 : 520;

  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(frequency, now);
  if (sound === 'attention') oscillator.frequency.setValueAtTime(880, now + 0.1);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.07, now + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + (sound === 'attention' ? 0.2 : 0.12));
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(now);
  oscillator.stop(now + (sound === 'attention' ? 0.21 : 0.13));
}

export function playUiSound(sound: UiSound) {
  if (typeof window === 'undefined' || window.localStorage.getItem(SOUND_SETTING) === 'off') return;

  if (sound === 'attention') {
    const lastPlayed = Number(window.localStorage.getItem(ATTENTION_SETTING) ?? 0);
    if (Date.now() - lastPlayed < 24 * 60 * 60 * 1000) return;
    window.localStorage.setItem(ATTENTION_SETTING, String(Date.now()));
  }

  const context = getAudioContext();
  if (!context) return;
  if (context.state === 'suspended') {
    void context.resume()
      .then(() => playTone(context, sound))
      .catch(error => console.debug('UI sound could not be played:', error));
    return;
  }
  playTone(context, sound);
}
