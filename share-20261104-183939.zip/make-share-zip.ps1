param(
    [string]$SourceDir = ".",
    [string]$OutZip = "share-$(Get-Date -Format 'yyyyMMdd-HHmmss').zip"
)

Add-Type -AssemblyName System.IO.Compression.FileSystem

$root    = (Resolve-Path $SourceDir).Path
$outPath = Join-Path (Get-Location).Path $OutZip

$excludeDirs = @(
  '.git','node_modules','.next','.nuxt','.svelte-kit','dist','build','out',
  'coverage','.turbo','.cache','.parcel-cache','.vercel','.netlify',
  'venv','.venv','__pycache__','.idea','.vscode','.angular','.expo'
)
$excludeFiles = @('.DS_Store','Thumbs.db','package-lock.json.bak')
$excludeExt   = @('.pyc','.log','.zip','.map')

Write-Host "Zipping: $root"
Write-Host "Output:  $outPath"

$zip = [System.IO.Compression.ZipFile]::Open($outPath, 'Create')
try {
    Get-ChildItem -Path $root -Recurse -File -Force | ForEach-Object {
        $rel   = $_.FullName.Substring($root.Length).TrimStart('\','/')
        $parts = $rel -split '[\\/]'

        if ($parts | Where-Object { $excludeDirs -contains $_ }) { return }
        if ($excludeFiles -contains $_.Name)                    { return }
        if ($excludeExt   -contains $_.Extension.ToLower())     { return }
        if ($_.Name -like '.env*')                              { return }
        if ($_.Name -eq $OutZip)                                { return }

        $entry = $rel -replace '\\','/'
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $zip, $_.FullName, $entry, 'Optimal') | Out-Null
    }
} finally { $zip.Dispose() }

$sizeMB = [math]::Round((Get-Item $outPath).Length / 1MB, 2)
Write-Host ""
Write-Host "Done: $OutZip ($sizeMB MB)"